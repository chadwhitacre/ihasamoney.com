from setuptools import setup, find_packages

setup( name='IHazMoney'
     , packages=find_packages()
      )
